﻿"""Minimal skill playground package."""
